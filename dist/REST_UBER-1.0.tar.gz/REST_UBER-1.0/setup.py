from distutils.core import setup
setup(name='REST_UBER',
      version='1.0',
      description='ubertool ecological risk models',
      author='Tom Purucker',
      author_email='purucker.tom@epa.gov',
      url='https://github.com/puruckertom/ubertool_ecorest',
      py_modules=['ubertool'],
      )
