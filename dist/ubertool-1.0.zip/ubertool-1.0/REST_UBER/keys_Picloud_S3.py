picloud_api_key='3355'
picloud_api_secretkey='212ed160e3f416fdac8a3b71c90f3016722856b9'

# amazon_s3_key='AKIAJIHTMZIZEAQIAWBA'
# amazon_s3_secretkey='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'

amazon_s3_key='AKIAJTO5LRXD5LULPX7Q'
amazon_s3_secretkey='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'

aws_access_key_id='AKIAJTO5LRXD5LULPX7Q'
aws_secret_access_key='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'

postgres_user = 'postgres'
postgres_pwd = 'postgres'